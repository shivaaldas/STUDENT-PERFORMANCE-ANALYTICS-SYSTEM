# Student Performance Analytics System — Project Documentation

## 1. Title & Student Details
- **Project Title:** Student Performance Analytics System
- **Domain:** Data Analysis / Python Application Development
- **Author/Student Name:** [Your Name]
- **Roll Number / ID:** [Your ID]

---

## 2. Objective
This project automates the evaluation of student academic records using Python's data analysis stack (**Pandas** and **NumPy**). It reads raw mark sheets, calculates statistical performance metrics, assigns letter grades based on predefined benchmarks, and generates summary reports for educators.

---

## 3. Technologies Used
- **Python (v3.x)**
- **Pandas** (Data manipulation and CSV handling)
- **NumPy** (Numerical aggregation and statistical metrics)

---

## 4. Dataset Description
The dataset (`students.csv`) contains **20 realistic student records** across four departments:
- **Attributes:** `StudentID`, `Name`, `Department`, `Math`, `Science`, `English`, `Attendance`

---

## 5. Key Functions
- `calculate_total(marks)`: Computes sum of subject scores.
- `calculate_average(marks)`: Computes mean percentage.
- `assign_grade(avg)`: Returns Grade (A: ≥85, B: ≥70, C: ≥50, D: <50).
- `pass_fail(avg)`: Assigns "Pass" (≥50) or "Fail" (<50).

---

## 6. Execution & Output Summary
Executing `python main.py` computes total/average scores, outputs class summary metrics in the terminal, and exports a detailed summary to `student_analytics_results.csv`.