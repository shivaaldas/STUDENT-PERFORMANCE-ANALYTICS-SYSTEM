import pandas as pd
import numpy as np
from functions import calculate_total, calculate_average, assign_grade, pass_fail

def main():
    print("=" * 50)
    print("   STUDENT PERFORMANCE ANALYTICS SYSTEM   ")
    print("=" * 50)

    # Step 1 - Load dataset
    try:
        df = pd.read_csv("students.csv")
        print(f"\\nSuccessfully loaded dataset with {len(df)} records.\\n")
    except FileNotFoundError:
        print("Error: 'students.csv' not found. Please place it in the same directory.")
        return

    # Step 2 - Process data
    df["Total"] = df.apply(lambda row: calculate_total([row["Math"], row["Science"], row["English"]]), axis=1)
    df["Average"] = df["Total"] / 3.0
    df["Grade"] = df["Average"].apply(assign_grade)
    df["Status"] = df["Average"].apply(pass_fail)

    # Step 3 - Analysis & Results
    print("----- OVERALL CLASS SUMMARY -----")
    print(f"Total Students Analysed: {len(df)}")
    print(f"Class Average Score:     {np.mean(df['Average']):.2f}%")
    print(f"Highest Average Score:   {df['Average'].max():.2f}% ({df.loc[df['Average'].idxmax(), 'Name']} - {df.loc[df['Average'].idxmax(), 'Department']})")
    print(f"Lowest Average Score:    {df['Average'].min():.2f}% ({df.loc[df['Average'].idxmin(), 'Name']} - {df.loc[df['Average'].idxmin(), 'Department']})")
    print(f"Total Passed Students:   {len(df[df['Status'] == 'Pass'])}")
    print(f"Total Failed Students:   {len(df[df['Status'] == 'Fail'])}")

    print("\\n----- SUBJECT-WISE AVERAGES -----")
    subject_means = df[["Math", "Science", "English"]].mean()
    for sub, score in subject_means.items():
        print(f"{sub:10s}: {score:.2f}%")

    print("\\n----- DEPARTMENT-WISE PERFORMANCE -----")
    dept_summary = df.groupby("Department")["Average"].mean().reset_index()
    for _, row in dept_summary.iterrows():
        print(f"{row['Department']:10s}: {row['Average']:.2f}%")

    # Step 4 - Save processed results
    output_file = "student_analytics_results.csv"
    df.to_csv(output_file, index=False)
    print(f"\\nProcessed detailed analytics saved to '{output_file}'.")
    print("=" * 50)

if __name__ == "__main__":
    main()
