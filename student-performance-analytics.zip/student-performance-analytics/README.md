"""# Student Performance Analytics System

A Python-based data analytics application using **Pandas** and **NumPy** to evaluate and visualize student academic performance metrics.